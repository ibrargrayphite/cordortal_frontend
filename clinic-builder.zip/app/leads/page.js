"use client";

import React, { useState, useEffect } from 'react';
import { Button, Modal, Form, Alert } from 'react-bootstrap';
import { useRouter } from 'next/navigation';
import { getAuthHeaders, isAuthenticated, logout } from '../utils/auth';
import { fetchPagesData } from '../utils/fetchPagesData';
import { useToast } from '../components/Toast';
import { DataLoader, OverlayLoader } from '../components/LoadingSpinner';
import styles from './leads.module.css';

const LeadsPage = () => {
  const [leads, setLeads] = useState([]);
  const [leadsCount, setLeadsCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [pageSize, setPageSize] = useState(10); // Items per page
  const [nextUrl, setNextUrl] = useState(null);
  const [previousUrl, setPreviousUrl] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [orgData, setOrgData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [templatesLoading, setTemplatesLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('leads');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [editingLeadId, setEditingLeadId] = useState(null);
  const [deletingLeadId, setDeletingLeadId] = useState(null);
  const [pageLoading, setPageLoading] = useState(false);
  const [fadeOut, setFadeOut] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showAddTemplateModal, setShowAddTemplateModal] = useState(false);
  const [showEditTemplateModal, setShowEditTemplateModal] = useState(false);
  const [showDeleteTemplateModal, setShowDeleteTemplateModal] = useState(false);
  const [selectedLead, setSelectedLead] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    message: '',
    source: ''
  });
  const [templateFormData, setTemplateFormData] = useState({
    name: '',
    template: ''
  });
  const [saving, setSaving] = useState(false);
  const [templateSaving, setTemplateSaving] = useState(false);
  
  const router = useRouter();
  const { showError, showSuccess, showWarning } = useToast();

  useEffect(() => {
    // Check auth and fetch data immediately
    if (!isAuthenticated()) {
      window.location.replace('/login');
      return;
    }

    // Fetch both leads and organization data in parallel
    Promise.all([fetchLeads(1, false, searchQuery), fetchOrgData()]);
  }, []);

  // Fetch templates when templates tab is active
  useEffect(() => {
    if (activeTab === 'templates' && templates.length === 0) {
      fetchTemplates();
    }
  }, [activeTab]);

  const fetchLeads = async (page = 1, isPageChange = false, search = '', customPageSize = null) => {
    try {
      if (isPageChange) {
        setPageLoading(true);
        setFadeOut(true);
        // Small delay for smooth fade out animation
        await new Promise(resolve => setTimeout(resolve, 200));
      } else {
        setLoading(true);
      }
      
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
      const searchParam = search ? `&q=${encodeURIComponent(search)}` : '';
      const pageSizeToUse = customPageSize || pageSize;
      const response = await fetch(`${baseUrl}/leads/?page=${page}&page_size=${pageSizeToUse}${searchParam}`, {
        method: 'GET',
        headers: getAuthHeaders()
      });

      if (response.status === 401) {
        logout();
        window.location.replace('/login');
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      // Handle paginated response structure
      const leadsArray = data.results ? data.results : (Array.isArray(data) ? data : []);
      const totalCount = data.count || leadsArray.length;
      const calculatedTotalPages = Math.ceil(totalCount / pageSizeToUse);
      
      setLeads(leadsArray);
      setLeadsCount(totalCount);
      setCurrentPage(page);
      setTotalPages(calculatedTotalPages);
      setNextUrl(data.next);
      setPreviousUrl(data.previous);
      
      if (isPageChange) {
        setFadeOut(false);
        // Small delay for smooth fade in animation
        await new Promise(resolve => setTimeout(resolve, 100));
      }
    } catch (err) {
      console.error('Leads fetch error:', err);
      showError('Failed to load leads. Please try again.');
    } finally {
      if (isPageChange) {
        setPageLoading(false);
      } else {
        setLoading(false);
      }
    }
  };

  // Pagination handlers
  const handlePageChange = (page) => {
    console.log('handlePageChange called with page:', page, 'currentPage:', currentPage, 'totalPages:', totalPages);
    if (page >= 1 && page <= totalPages && page !== currentPage && !pageLoading) {
      console.log('Fetching page:', page);
      fetchLeads(page, true, searchQuery); // Pass search query for pagination
    } else {
      console.log('Page change blocked:', {
        page,
        currentPage,
        totalPages,
        pageLoading,
        isValidPage: page >= 1 && page <= totalPages,
        isDifferentPage: page !== currentPage,
        notLoading: !pageLoading
      });
    }
  };

  const handlePreviousPage = () => {
    if (previousUrl && currentPage > 1 && !pageLoading) {
      handlePageChange(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (nextUrl && currentPage < totalPages && !pageLoading) {
      handlePageChange(currentPage + 1);
    }
  };

  // API-based search functionality
  const handleSearchSubmit = async (e) => {
    e.preventDefault();
    const query = searchInput.trim();
    setSearchQuery(query);
    setIsSearching(true);
    setCurrentPage(1);
    try {
      await fetchLeads(1, true, query);
    } finally {
      setIsSearching(false);
    }
  };

  const handleClearSearch = async () => {
    setSearchInput('');
    setSearchQuery('');
    setCurrentPage(1);
    setIsSearching(true);
    try {
      await fetchLeads(1, true, '');
    } finally {
      setIsSearching(false);
    }
  };

  const fetchOrgData = async () => {
    try {
      const data = await fetchPagesData();
      setOrgData(data);
    } catch (err) {
      console.error('Org data fetch error:', err);
    }
  };

  const fetchTemplates = async () => {
    try {
      setTemplatesLoading(true);
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
      const response = await fetch(`${baseUrl}/leads/organization-templates/`, {
        method: 'GET',
        headers: getAuthHeaders()
      });

      if (response.status === 401) {
        logout();
        window.location.replace('/login');
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setTemplates(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error('Templates fetch error:', err);
      showError('Failed to load templates. Please try again.');
    } finally {
      setTemplatesLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    window.location.replace('/login');
  };


  const [viewingLeadId, setViewingLeadId] = useState(null);

  const handleLeadClick = (leadId) => {
    setViewingLeadId(leadId);
    // Add a small delay to show the loading state
    setTimeout(() => {
      router.push(`/leads/detail?id=${leadId}`);
    }, 300);
  };

  // CRUD Functions
  const handleAddLead = () => {
    setFormData({
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      message: '',
      source: ''
    });
    setShowAddModal(true);
  };

  const handleEditLead = (lead) => {
    setEditingLeadId(lead.id);
    setTimeout(() => {
      setSelectedLead(lead);
      setFormData({
        first_name: lead.first_name || '',
        last_name: lead.last_name || '',
        email: lead.email || '',
        phone: lead.phone || '',
        message: lead.message || '',
        source: lead.source || ''
      });
      setShowEditModal(true);
      setEditingLeadId(null);
    }, 200);
  };

  const handleDeleteLead = (lead) => {
    setSelectedLead(lead);
    setShowDeleteModal(true);
  };

  const handleSaveLead = async () => {
    try {
      setSaving(true);
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
      
      const payload = {
        first_name: formData.first_name,
        last_name: formData.last_name,
        email: formData.email,
        phone: formData.phone,
        message: formData.message,
        source: formData.source
      };

      let response;
      if (showEditModal) {
        // Update existing lead using /leads/{id}
        response = await fetch(`${baseUrl}/leads/${selectedLead.id}/`, {
          method: 'PUT',
          headers: {
            ...getAuthHeaders(),
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
      } else {
        // Create new lead
        response = await fetch(`${baseUrl}/leads/`, {
          method: 'POST',
          headers: {
            ...getAuthHeaders(),
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
      }

      if (response.status === 401) {
        logout();
        window.location.replace('/login');
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const savedLead = await response.json();
      
      if (showEditModal) {
        // Update the lead in the list
        const updatedLeads = leads.map(lead => 
          lead.id === selectedLead.id ? savedLead : lead
        );
        setLeads(updatedLeads);
        showSuccess('Lead updated successfully!');
      } else {
        // Refresh the current page to show the new lead
        fetchLeads(currentPage, true, searchQuery);
        showSuccess('Lead created successfully!');
      }

      setShowAddModal(false);
      setShowEditModal(false);
      setSelectedLead(null);
      setFormData({
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
        message: '',
        source: ''
      });
    } catch (err) {
      console.error('Save error:', err);
      showError(`Failed to ${showEditModal ? 'update' : 'create'} lead. Please try again.`);
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    try {
      setSaving(true);
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
      
      // Delete lead using /leads/{id}
      const response = await fetch(`${baseUrl}/leads/${selectedLead.id}/`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });

      if (response.status === 401) {
        logout();
        window.location.replace('/login');
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // Refresh the current page after deletion
      // If this was the last item on the page and we're not on page 1, go to previous page
      const isLastItemOnPage = leads.length === 1 && currentPage > 1;
      const pageToFetch = isLastItemOnPage ? currentPage - 1 : currentPage;
      fetchLeads(pageToFetch, true, searchQuery);
      
      showSuccess('Lead deleted successfully!');
      setShowDeleteModal(false);
      setSelectedLead(null);
    } catch (err) {
      console.error('Delete error:', err);
      showError('Failed to delete lead. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleFormChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Template CRUD Functions
  const handleAddTemplate = () => {
    setTemplateFormData({
      name: '',
      template: ''
    });
    setShowAddTemplateModal(true);
  };

  const handleEditTemplate = (template) => {
    // Redirect to template detail page in edit mode
    router.push(`/templates/detail?id=${template.id}&editMode=true`);
  };

  const handleDeleteTemplate = (template) => {
    setSelectedTemplate(template);
    setShowDeleteTemplateModal(true);
  };

  const handleSaveTemplate = async () => {
    try {
      setTemplateSaving(true);
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
      
      const payload = {
        name: templateFormData.name,
        template: templateFormData.template
      };

      let response;
      if (showEditTemplateModal) {
        // Update template
        response = await fetch(`${baseUrl}/leads/organization-templates/${selectedTemplate.id}/`, {
          method: 'PUT',
          headers: {
            ...getAuthHeaders(),
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
      } else {
        // Create template
        response = await fetch(`${baseUrl}/leads/organization-templates/`, {
          method: 'POST',
          headers: {
            ...getAuthHeaders(),
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
      }

      if (response.status === 401) {
        logout();
        window.location.replace('/login');
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      showSuccess(showEditTemplateModal ? 'Template updated successfully!' : 'Template created successfully!');
      
      // Refresh templates
      await fetchTemplates();
      
      // Close modal and reset form
      setShowAddTemplateModal(false);
      setShowEditTemplateModal(false);
      setTemplateFormData({ name: '', template: '' });
      setSelectedTemplate(null);
    } catch (err) {
      console.error('Template save error:', err);
      showError('Failed to save template. Please try again.');
    } finally {
      setTemplateSaving(false);
    }
  };

  const handleConfirmDeleteTemplate = async () => {
    try {
      setTemplateSaving(true);
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
      
      const response = await fetch(`${baseUrl}/leads/organization-templates/${selectedTemplate.id}/`, {
        method: 'DELETE',
        headers: getAuthHeaders()
      });

      if (response.status === 401) {
        logout();
        window.location.replace('/login');
        return;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      showSuccess('Template deleted successfully!');
      
      // Refresh templates
      await fetchTemplates();
      
      // Close modal
      setShowDeleteTemplateModal(false);
      setSelectedTemplate(null);
    } catch (err) {
      console.error('Template delete error:', err);
      showError('Failed to delete template. Please try again.');
    } finally {
      setTemplateSaving(false);
    }
  };

  const handleTemplateFormChange = (field, value) => {
    setTemplateFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <div className={styles.adminContainer}>
      {/* Simple Header - Only Domain Name and Logout */}
      <div className={styles.simpleHeader}>
        <div className={styles.headerContent}>
          <h1 className={styles.domainName}>
            {orgData?.name || orgData?.title || 'Clinic Admin'}
          </h1>
          <Button
            variant="outline-danger"
            size="sm"
            onClick={handleLogout}
            className={styles.logoutButton}
          >
            <i className="fas fa-sign-out-alt me-2"></i>
            Logout
          </Button>
        </div>
      </div>

      <div className={styles.mainWrapper}>
        {/* Modern EFC-POS Style Sidebar */}
        <div className={styles.sidebar}>
          <div className={styles.sidebarContent}>
            <div className={styles.sidebarSection}>
              <ul className={styles.navList}>
                <li 
                  className={`${styles.navItem} ${activeTab === 'leads' ? styles.active : ''}`}
                  onClick={() => setActiveTab('leads')}
                >
                  <i className="fas fa-users"></i>
                  Leads
                </li>
                <li 
                  className={`${styles.navItem} ${activeTab === 'templates' ? styles.active : ''}`}
                  onClick={() => setActiveTab('templates')}
                >
                  <i className="fas fa-file-alt"></i>
                  Templates
                </li>
              </ul>
            </div>
            

          </div>
        </div>

        {/* Content Area */}
        <div className={styles.contentArea}>
          {activeTab === 'leads' && (
            <>
              {/* Modern Header */}
              <div className={styles.modernHeader}>
                <div className={styles.headerLeft}>
                  <h1 className={styles.pageTitle}>Lead Management</h1>
                  <p className={styles.pageSubtitle}>Manage your team members and staff</p>
                </div>
                <div className={styles.headerRight}>
                  <button
                    onClick={handleAddLead}
                    className={styles.modernAddButton}
                  >
                    <i className="fas fa-plus"></i>
                    Add New Lead
                  </button>
                </div>
              </div>

              {/* Stats Cards */}
              {!loading && (
                <div className={styles.statsContainer}>
                  <div className={styles.statsCard}>
                    <div className={styles.statsContent}>
                      <div className={styles.statsLeft}>
                        <h3 className={styles.statsTitle}>Total Leads</h3>
                        <h2 className={styles.statsNumber}>{leadsCount}</h2>
                      </div>
                      <div className={styles.statsIconContainer} style={{backgroundColor: '#dbeafe'}}>
                        <i className="fas fa-users" style={{color: '#3b82f6'}}></i>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Modern Search Section */}
              {!loading && (
                <div className={styles.modernSearchSection}>
                  <div className={styles.searchCard}>
                    <form onSubmit={handleSearchSubmit} className={styles.modernSearchForm}>
                      <div className={styles.modernSearchInputWrapper}>
                        <i className="fas fa-search"></i>
                        <input
                          type="text"
                          placeholder="Search staff..."
                          value={searchInput}
                          onChange={(e) => setSearchInput(e.target.value)}
                          className={styles.modernSearchInput}
                          disabled={isSearching}
                        />
                        {searchQuery && (
                          <button
                            type="button"
                            onClick={handleClearSearch}
                            className={styles.modernClearButton}
                            title="Clear search"
                          >
                            <i className="fas fa-times"></i>
                          </button>
                        )}
                        {isSearching && (
                          <div className={styles.modernSearchLoading}>
                            <i className="fas fa-spinner fa-spin"></i>
                          </div>
                        )}
                      </div>
                    </form>
                    {searchQuery && (
                      <div className={styles.modernSearchResults}>
                        {leadsCount} leads found for "{searchQuery}"
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Loading State */}
              {loading && (
                <DataLoader message="Loading leads..." />
              )}

              {/* Modern Content Card */}
              {!loading && (
                <div className={styles.modernContentCard}>
                  <div className={styles.modernContentHeader}>
                    <div className={styles.contentHeaderLeft}>
                      <h3 className={styles.contentSectionTitle}>All Staff</h3>
                      <p className={styles.contentSectionSubtitle}>Manage and edit your team members</p>
                    </div>
                    <div className={styles.contentHeaderRight}>
                      <span className={styles.modernResultsCount}>
                        {searchQuery 
                          ? `${leadsCount} leads found` 
                          : `${((currentPage - 1) * pageSize) + 1}-${Math.min(currentPage * pageSize, leadsCount)} of ${leadsCount} items`
                        }
                      </span>
                      <select 
                        className={styles.modernShowSelect}
                        value={pageSize}
                        onChange={(e) => {
                          const newPageSize = parseInt(e.target.value);
                          console.log('Changing page size from', pageSize, 'to', newPageSize);
                          setPageSize(newPageSize);
                          setCurrentPage(1);
                          // Recalculate total pages immediately
                          const newTotalPages = Math.ceil(leadsCount / newPageSize);
                          setTotalPages(newTotalPages);
                          console.log('New total pages:', newTotalPages);
                          // Call fetchLeads with the new page size directly
                          fetchLeads(1, false, searchQuery, newPageSize);
                        }}
                      >
                        <option value={10}>10</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                      </select>
                      <span className={styles.modernPerPageText}>per page</span>
                    </div>
                  </div>
                  
                  <div className={`${styles.tableContainer} ${fadeOut ? styles.fadeOut : styles.fadeIn} ${pageLoading ? styles.loading : ''}`}>
                    <table className={styles.table}>
                      <thead>
                        <tr>
                          <th>NAME</th>
                          <th>EMAIL</th>
                          <th>PHONE</th>
                          <th>SOURCE</th>
                          <th style={{ textAlign: 'center' }}>ACTIONS</th>
                        </tr>
                      </thead>
                      <tbody>
                        {leads.length > 0 ? leads.map((lead) => (
                          <tr key={lead.id} className={styles.tableRow}>
                                                        <td className={styles.modernNameCell}>
                              <div className={styles.modernProfileInfo}>
                                <div className={styles.modernAvatar}>
                                  <img src={`https://ui-avatars.com/api/?name=${lead.first_name}+${lead.last_name}&background=3b82f6&color=fff&size=40`} alt="Avatar" />
                                </div>
                                <div className={styles.modernNameInfo}>
                                  <div className={styles.modernFullName}>{lead.first_name} {lead.last_name}</div>
                                </div>
                              </div>
                            </td>
                            <td className={styles.modernEmailCell}>
                              <a href={`mailto:${lead.email}`} className={styles.modernEmailLink}>
                                {lead.email}
                              </a>
                            </td>
                            <td className={styles.modernPhoneCell}>
                              <a href={`tel:${lead.phone}`} className={styles.modernPhoneLink}>
                                {lead.phone}
                              </a>
                            </td>
                            <td className={styles.modernSourceCell}>
                              {lead.source ? (
                                <span className={styles.modernSourceTag}>{lead.source}</span>
                              ) : (
                                <span className={styles.modernNoSource}>Not specified</span>
                              )}
                            </td>
                            <td className={styles.modernActionCell}>
                              <div className={styles.modernActionButtons}>
                                <button
                                  onClick={() => handleLeadClick(lead.id)}
                                  disabled={viewingLeadId === lead.id}
                                  className={styles.modernViewButton}
                                >
                                  {viewingLeadId === lead.id ? (
                                    <>
                                      <i className="fas fa-spinner fa-spin"></i>
                                      Loading...
                                    </>
                                  ) : (
                                    <>
                                      <i className="fas fa-eye me-1"></i>
                                      View
                                    </>
                                  )}
                                </button>
                                <button
                                  onClick={() => handleEditLead(lead)}
                                  disabled={editingLeadId === lead.id}
                                  className={styles.modernEditButton}
                                >
                                  {editingLeadId === lead.id ? (
                                    <>
                                      <i className="fas fa-spinner fa-spin"></i>
                                      Loading...
                                    </>
                                  ) : (
                                    <>
                                      <i className="fas fa-edit me-1"></i>
                                      Edit
                                    </>
                                  )}
                                </button>
                                <button
                                  onClick={() => handleDeleteLead(lead)}
                                  className={styles.modernDeleteButton}
                                >
                                  <i className="fas fa-trash me-1"></i>
                                  Delete
                                </button>
                              </div>
                            </td>
                          </tr>
                        )) : (
                          <tr>
                            <td colSpan="5" className={styles.emptyRow}>
                              <div className={styles.emptyState}>
                                <i className={`fas ${searchQuery ? 'fa-search' : 'fa-users'}`}></i>
                                <h4>{searchQuery ? 'No matching leads found' : 'No leads found'}</h4>
                                <p>
                                  {searchQuery 
                                    ? 'Try adjusting your search terms or clear the search to see all leads.'
                                    : 'Start by adding your first lead using the "Add Lead" button above.'
                                  }
                                </p>
                              </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                  
                  {/* Modern Pagination */}
                  {!searchQuery && totalPages > 1 && (
                    <div className={styles.modernPaginationWrapper}>
                      <div className={styles.modernPaginationControls}>
                        <button
                          onClick={handlePreviousPage}
                          disabled={!previousUrl || currentPage === 1 || pageLoading}
                          className={`${styles.modernPaginationButton} ${(!previousUrl || currentPage === 1) ? styles.disabled : ''}`}
                        >
                          <i className="fas fa-chevron-left"></i>
                        </button>
                        
                        <div className={styles.modernPageNumbers}>
                          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                            let pageNum;
                            if (totalPages <= 5) {
                              pageNum = i + 1;
                            } else if (currentPage <= 3) {
                              pageNum = i + 1;
                            } else if (currentPage >= totalPages - 2) {
                              pageNum = totalPages - 4 + i;
                            } else {
                              pageNum = currentPage - 2 + i;
                            }
                            
                            return (
                              <button
                                key={pageNum}
                                onClick={() => handlePageChange(pageNum)}
                                disabled={pageLoading}
                                className={`${styles.modernPageButton} ${currentPage === pageNum ? styles.modernActivePage : ''}`}
                              >
                                {pageNum}
                              </button>
                            );
                          })}
                        </div>
                        
                        <button
                          onClick={handleNextPage}
                          disabled={!nextUrl || currentPage === totalPages || pageLoading}
                          className={`${styles.modernPaginationButton} ${(!nextUrl || currentPage === totalPages) ? styles.disabled : ''}`}
                        >
                          <i className="fas fa-chevron-right"></i>
                        </button>
                      </div>
                    </div>
                  )}
                  
                  {/* Debug Info - Remove after testing */}
                  <div style={{padding: '1rem', fontSize: '0.8rem', color: '#666', textAlign: 'center'}}>
                    Debug: Current Page: {currentPage}, Total Pages: {totalPages}, Page Size: {pageSize}, Total Leads: {leadsCount}
                  </div>
                </div>
              )}
            </>
          )}

          {activeTab === 'templates' && (
            <>
              {/* Modern Templates Header */}
              <div className={styles.modernHeader}>
                <div className={styles.headerLeft}>
                  <h1 className={styles.pageTitle}>Template Management</h1>
                  <p className={styles.pageSubtitle}>Manage your email templates and forms</p>
                </div>
                <div className={styles.headerRight}>
                  <button
                    onClick={handleAddTemplate}
                    className={styles.modernAddButton}
                  >
                    <i className="fas fa-plus"></i>
                    Add New Template
                  </button>
                </div>
              </div>

              {/* Templates Stats Cards */}
              {!templatesLoading && (
                <div className={styles.statsContainer}>
                  <div className={styles.statsCard}>
                    <div className={styles.statsContent}>
                      <div className={styles.statsLeft}>
                        <h3 className={styles.statsTitle}>Total Templates</h3>
                        <h2 className={styles.statsNumber}>{templates.length}</h2>
                      </div>
                      <div className={styles.statsIconContainer} style={{backgroundColor: '#dbeafe'}}>
                        <i className="fas fa-file-alt" style={{color: '#3b82f6'}}></i>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Loading State */}
              {templatesLoading && (
                <DataLoader message="Loading templates..." />
              )}

              {/* Modern Templates Content Card */}
              {!templatesLoading && (
                <div className={styles.modernContentCard}>
                  <div className={styles.modernContentHeader}>
                    <div className={styles.contentHeaderLeft}>
                      <h3 className={styles.contentSectionTitle}>All Templates</h3>
                      <p className={styles.contentSectionSubtitle}>Manage and edit your email templates</p>
                    </div>
                    <div className={styles.contentHeaderRight}>
                      <span className={styles.modernResultsCount}>
                        {templates.length} templates
                      </span>
                    </div>
                  </div>
                  
                  <div className={styles.tableContainer}>
                    <table className={styles.table}>
                      <thead>
                        <tr>
                          <th>NAME</th>
                          <th>CONTENT</th>
                          <th style={{ textAlign: 'center' }}>ACTIONS</th>
                        </tr>
                      </thead>
                      <tbody>
                        {templates.length > 0 ? templates.map((template) => (
                          <tr key={template.id} className={styles.tableRow}>
                            <td className={styles.modernNameCell}>
                              <div className={styles.modernProfileInfo}>
                                <div className={styles.modernAvatar}>
                                  <i className="fas fa-file-alt" style={{color: '#3b82f6', fontSize: '1.5rem'}}></i>
                                </div>
                                <div className={styles.modernNameInfo}>
                                  <div className={styles.modernFullName}>{template.name}</div>
                                </div>
                              </div>
                            </td>
                            <td className={styles.modernEmailCell}>
                              <div className={styles.templatePreview}>
                                {template.template.length > 100 
                                  ? `${template.template.substring(0, 100)}...` 
                                  : template.template
                                }
                              </div>
                            </td>
                            <td className={styles.modernActionCell}>
                              <div className={styles.modernActionButtons}>
                                <button 
                                  className={styles.modernViewButton}
                                  onClick={() => router.push(`/templates/detail?id=${template.id}`)}
                                >
                                  <i className="fas fa-eye"></i>
                                  View
                                </button>
                                <button 
                                  className={styles.modernEditButton}
                                  onClick={() => handleEditTemplate(template)}
                                >
                                  <i className="fas fa-edit"></i>
                                  Edit
                                </button>
                                <button 
                                  className={styles.modernDeleteButton}
                                  onClick={() => handleDeleteTemplate(template)}
                                >
                                  <i className="fas fa-trash"></i>
                                  Delete
                                </button>
                              </div>
                            </td>
                          </tr>
                        )) : (
                          <tr>
                            <td colSpan="3" className={styles.emptyRow}>
                              <div className={styles.emptyState}>
                                <i className="fas fa-file-alt"></i>
                                <h4>No templates found</h4>
                                <p>Start by adding your first template using the "Add Template" button above.</p>
                              </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Add/Edit Modal */}
      <Modal show={showAddModal || showEditModal} onHide={() => {setShowAddModal(false); setShowEditModal(false);}}>
        <Modal.Header closeButton>
          <Modal.Title>{showEditModal ? 'Edit Lead' : 'Add New Lead'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <div className="row">
              <div className="col-md-6">
                <Form.Group className="mb-3">
                  <Form.Label>First Name</Form.Label>
                  <Form.Control
                    type="text"
                    value={formData.first_name}
                    onChange={(e) => handleFormChange('first_name', e.target.value)}
                    placeholder="Enter first name"
                  />
                </Form.Group>
              </div>
              <div className="col-md-6">
                <Form.Group className="mb-3">
                  <Form.Label>Last Name</Form.Label>
                  <Form.Control
                    type="text"
                    value={formData.last_name}
                    onChange={(e) => handleFormChange('last_name', e.target.value)}
                    placeholder="Enter last name"
                  />
                </Form.Group>
              </div>
            </div>
            <Form.Group className="mb-3">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                value={formData.email}
                onChange={(e) => handleFormChange('email', e.target.value)}
                placeholder="Enter email address"
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Phone</Form.Label>
              <Form.Control
                type="tel"
                value={formData.phone}
                onChange={(e) => handleFormChange('phone', e.target.value)}
                placeholder="Enter phone number"
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Source</Form.Label>
              <Form.Select
                value={formData.source}
                onChange={(e) => handleFormChange('source', e.target.value)}
              >
                <option value="">Select source</option>
                <option value="WEBSITE">Website</option>
                <option value="GMAIL">Gmail</option>
                
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Message</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={formData.message}
                onChange={(e) => handleFormChange('message', e.target.value)}
                placeholder="Enter message"
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => {setShowAddModal(false); setShowEditModal(false);}}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSaveLead} disabled={saving}>
            {saving ? (
              <>
                <span className="spinner-border spinner-border-sm me-2"></span>
                Saving...
              </>
            ) : (
              showEditModal ? 'Update Lead' : 'Add Lead'
            )}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete the lead for {selectedLead?.first_name} {selectedLead?.last_name}?
          This action cannot be undone.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleConfirmDelete} disabled={saving}>
            {saving ? (
              <>
                <span className="spinner-border spinner-border-sm me-2"></span>
                Deleting...
              </>
            ) : (
              'Delete Lead'
            )}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Add/Edit Template Modal */}
      <Modal show={showAddTemplateModal || showEditTemplateModal} onHide={() => {setShowAddTemplateModal(false); setShowEditTemplateModal(false);}}>
        <Modal.Header closeButton>
          <Modal.Title>{showEditTemplateModal ? 'Edit Template' : 'Add New Template'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Template Name</Form.Label>
              <Form.Control
                type="text"
                value={templateFormData.name}
                onChange={(e) => handleTemplateFormChange('name', e.target.value)}
                placeholder="Enter template name"
                maxLength={255}
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Template Body</Form.Label>
              <Form.Control
                as="textarea"
                rows={8}
                value={templateFormData.template}
                onChange={(e) => handleTemplateFormChange('template', e.target.value)}
                placeholder="Enter template content"
              />

            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => {setShowAddTemplateModal(false); setShowEditTemplateModal(false);}}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSaveTemplate} disabled={templateSaving}>
            {templateSaving ? (
              <>
                <span className="spinner-border spinner-border-sm me-2"></span>
                Saving...
              </>
            ) : (
              showEditTemplateModal ? 'Update Template' : 'Add Template'
            )}
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Template Confirmation Modal */}
      <Modal show={showDeleteTemplateModal} onHide={() => setShowDeleteTemplateModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Delete Template</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete the template "{selectedTemplate?.name}"?
          This action cannot be undone.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteTemplateModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleConfirmDeleteTemplate} disabled={templateSaving}>
            {templateSaving ? (
              <>
                <span className="spinner-border spinner-border-sm me-2"></span>
                Deleting...
              </>
            ) : (
              'Delete Template'
            )}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default LeadsPage;