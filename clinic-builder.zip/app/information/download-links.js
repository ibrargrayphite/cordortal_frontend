export const file1 = "../../assets/documents/EqualityAndDiversityPolicy.doc";
export const file2 = "../../assets/documents/ViolenceAndAggressionPolicy.docx";
export const file3 = "../../assets/documents/SafeguardingPolicy.doc";
export const file4 = "../../assets/documents/DentalX.docx";
export const file5 = "../../assets/documents/MissionStatement.doc";
export const file6 = "../../assets/documents/WorkingTogether.doc";
export const file7 = "../../assets/documents/ComplaintsHandlingPolicy.docx";
export const file8 = "../../assets/documents/ClinicalGovernancePolicy.doc";
