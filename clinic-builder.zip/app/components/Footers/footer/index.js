"use client";
import { Col, Container, Row } from "react-bootstrap";
import styles from "./Footer.module.css";
import ContactCard from "../../ContactCard";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Cqc from "../../../../public/assets/images/footer/cqc.svg";
import Nhs from "../../../../public/assets/images/footer/nhs.svg";
import Gdc from "../../../../public/assets/images/footer/gdc.jpeg";
import HoursOfOperation from "../../HoursOfOperations";
import CustomButton from "../../CustomButton";
import { useTheme } from "../../../context/ThemeContext";
import { usePages } from '../../../context/PagesContext';
import { isAuthenticated } from '../../../utils/auth';
import { useState, useEffect } from 'react';

const Footer = ({ src, refersrc, title,data,media,noBgColor,footerLogin }) => {
  const { pages } = usePages();
  const ContactCardData = pages.data || {};
  const theme = useTheme();
  const router = useRouter();
  const [authenticated, setAuthenticated] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // Delay mounting to ensure hydration is complete
    const timer = setTimeout(() => {
      setMounted(true);
      setAuthenticated(isAuthenticated());
    }, 100);

    return () => clearTimeout(timer);
  }, []);

  const handleNavigation = (path, external = false) => {
    if (external) {
      window.open(path, "_blank"); // For external links
    } else {
      router.push(path); // For internal navigation
    }
  };

  const footerLinks = [
    { label: "Home", path: "/" },
    { label: "About Us", path: "/about-us" },
    { label: "Meet The Team", path: "/team" },
    { label: "Contact Us", path: "/contact-us" },
    { label: "Privacy Policy", path: "/privacy-policy" },
    { label: "Pricing", path: "/information/pricing" },
    { label: "Information For Patients", path: "/information/forpatient" },
    { label: "What We Offer", path: "/information/pricing" },
    { label: "Modern Slavery Policy", path: "/modern-slavery" },
  ];

  const handleBooking = (src) => {
    window.open(src, "_blank");
  };

  const handleHome = () => {
    router.push("/");
  };

  const handleLogin = () => {
    router.push('/login');
  };

  return (
    <>
      <footer>
        
        {
         ContactCardData && Object.keys(ContactCardData).length > 1 ?
         (<div className={styles.contactCard}>
          <ContactCard data={ContactCardData} />
        </div>):""
        }
        
        <div className={styles.footerTopWhiteSpace}></div>
        <Container
          fluid
          className={styles.contentMain}
          style={{ background: noBgColor?"":"#1f45b105", paddingTop: 30 }}
        >
          <Row className="max-lg:text-center">
            <Col xxl={2} />
            <Col lg={4} sm={12}>
              <HoursOfOperation hoursData={data?.hoursData} lunchTime={data?.lunchTime}/>
            </Col>
            {/* for mobile view */}
            <Col
              lg={4}
              sm={12}
              className={`${styles.bookingButton} ${styles.mobileBookingButton}`}
            >
              <CustomButton
                headline="Book an Appointment"
                onClick={handleBooking}
                className={styles.customButton}
              />
              <div>
                <ul className={styles.footerLink}>
                  <li>
                    <a style={{ cursor: "pointer" }}>Refer Your Patient</a>
                  </li>
                </ul>
              </div>
            </Col>
            <Col lg={4} sm={12} className={styles.mobileCenter}>
            {(typeof media == 'undefined'  ||  media)? 
              <>
                <p style={{ fontWeight: "bold", color: theme.content }}>
                  Affiliated
                </p>
                <div style={{ cursor: "pointer", marginTop: 20 }} className={`${styles.footerAward} max-lg:flex max-lg:justify-center`}>
                  <Cqc  height={"55px"} width={"170"}  alt="footerLogo1" onClick={() =>
                    window.open(
                      "https://www.cqc.org.uk/guidance-providers/dentists",
                      "_blank"
                    )
                  }/>
                </div>
                <div style={{ cursor: "pointer", marginTop: 20 }} className={`${styles.footerAward} max-lg:flex max-lg:justify-center`}>
                  <Nhs  height={"55px"} width={"30%"}  alt="nhs" onClick={() => window.open("https://www.nhs.uk/", "_blank")} />
                </div>
                <div className={`${styles.footerAward} max-lg:flex max-lg:justify-center`}>
                  <Image 
                  loading="lazy"
                    height={70}
                    width={70}
                    style={{ cursor: "pointer", marginTop: 20 }}
                    src={Gdc}
                    
                    alt="Certified by the General Dental Council"
                    onClick={() =>
                      window.open("https://www.gdc-uk.org/", "_blank")
                    }
                  />
                </div>
              </>
            : ""}
            </Col>
          </Row>
          {/* for desktop */}
          <Row>
            <Col lg={4} />
            <Col lg={4} sm={12} className={styles.hideOnMobile}>
              <div className={`max-lg:mt-0 max-xl:mt-40 ${styles.leftButton}`}>
                <CustomButton
                  headline="Book an Appointment"
                  onClick={() => handleBooking(src)}
                  className={styles.customButton}
                />
              </div>
              <div style={{ marginTop: 20 }}>
                <ul className={styles.footerLink}>
                  <li>
                    <a
                      href={refersrc}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ cursor: "pointer", textDecoration: "none", color: "inherit" }}
                    >
                      Refer Your Patient
                    </a>
                  </li>
                </ul>
              </div>
            </Col>
            <Col />
          </Row>
          <Row>
            <Col lg={2} />
            <Col lg={8} sm={12} className={styles.footerContent}>
              <div className={styles.contentMain}>
                <ul className={styles.footerLink}>
                  <Container fluid>
                    <Row>
                      {footerLinks.map((link, index) => (
                        <Col
                          key={index}
                          lg={4}
                          sm={6}
                          xs={6}
                        >
                          <li>
                            <a
                              style={{ cursor: "pointer" }}
                              onClick={() =>
                                handleNavigation(link.path, link.external || false)
                              }
                            >
                              {link.label}
                            </a>
                          </li>
                        </Col>
                      ))}
                      {/* Login button - always show if footerLogin is true and component is mounted */}
                      {mounted && footerLogin && (
                        <Col lg={4} sm={6} xs={6}>
                          <li>
                            <a
                              style={{ 
                                cursor: "pointer",
                                fontSize: "0.85rem",
                                opacity: 0.8,
                                fontStyle: "italic"
                              }}
                              onClick={handleLogin}
                            >
                              Login
                            </a>
                          </li>
                        </Col>
                      )}
                    </Row>
                  </Container>
                </ul>
              </div>
            </Col>
            <Col lg={2} />
          </Row>
        </Container>
      </footer>
      <div className={styles.copywrightText}>
        Copyright 2024 All Rights Reserved by{" "}
        <a
          onClick={handleHome}
          style={{
            color: "#52575D",
            textDecoration: "underline",
            cursor: "pointer",
          }}
        >
          {title}
        </a>
        .
      </div>
    </>
  );
};

export default Footer;
